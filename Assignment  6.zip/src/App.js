import React from "react";
import ProductCard from "./components/ProductCard";

function App() {
  return (
    <div style={{ padding: "2rem" }}>
      <ProductCard
        name="Wireless Earbuds"
        price="59.99"
        description="Experience high-quality sound without the wires. Long battery life and noise cancellation."
      />
    </div>
  );
}

export default App;
