const express = require("express");
const router = express.Router();
const {
  createBlogPost,
  getAllBlogPosts,
  getBlogPostById,
  deleteBlogPost,
} = require("../controllers/blogPostController");

router.post("/", createBlogPost);
router.get("/", getAllBlogPosts);
router.get("/:id", getBlogPostById);
router.delete("/:id", deleteBlogPost);

module.exports = router;
