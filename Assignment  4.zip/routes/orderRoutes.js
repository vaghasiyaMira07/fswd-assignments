const express = require("express");
const router = express.Router();
const auth = require("../middleware/auth");
const roleCheck = require("../middleware/roleCheck");
const {
  createOrder,
  getAllOrders,
  getOrder,
  updateOrder,
  deleteOrder,
} = require("../controllers/orderController");

router.use(auth);

router.post("/", createOrder);
router.get("/", getAllOrders);
router.get("/:id", getOrder);
router.put("/:id", updateOrder);
router.delete("/:id", roleCheck("admin"), deleteOrder); // admin-only

module.exports = router;
