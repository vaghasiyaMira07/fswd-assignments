const fs = require('fs');
const path = require('path');

const logger = (req, res, next) => {
  const log = `${new Date().toISOString()} ${req.method} ${req.originalUrl}\n`;
  fs.appendFile(path.join(__dirname, '../server.log'), log, err => {
    if (err) console.log('Logging failed', err);
  });
  next();
};

module.exports = logger;
