const BlogPost = require("../models/BlogPost");

exports.createBlogPost = async (req, res, next) => {
  try {
    const { title, content, author } = req.body;
    const post = new BlogPost({ title, content, author });
    await post.save();
    res.status(201).json(post);
  } catch (err) {
    next(err);
  }
};

exports.getAllBlogPosts = async (req, res, next) => {
  try {
    const posts = await BlogPost.find().populate("author");
    res.json(posts);
  } catch (err) {
    next(err);
  }
};

exports.getBlogPostById = async (req, res, next) => {
  try {
    const post = await BlogPost.findById(req.params.id).populate("author");
    if (!post) return res.status(404).json({ message: "Post not found" });
    res.json(post);
  } catch (err) {
    next(err);
  }
};

exports.deleteBlogPost = async (req, res, next) => {
  try {
    const deleted = await BlogPost.findByIdAndDelete(req.params.id);
    if (!deleted) return res.status(404).json({ message: "Post not found" });
    res.json({ message: "Post deleted successfully" });
  } catch (err) {
    next(err);
  }
};
